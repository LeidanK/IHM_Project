package com.example.ihm_project;

import org.junit.platform.launcher.Launcher;
import org.junit.platform.launcher.LauncherDiscoveryRequest;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;

public class TestReportRunner {

    public static void main(String[] args) {
        // 1. Setup JUnit Launcher
        LauncherDiscoveryRequest request = LauncherDiscoveryRequestBuilder.request()
                .selectors(selectClass(AutoUserTest.class)) // Selects the test class above
                .build();

        Launcher launcher = LauncherFactory.create();
        SummaryGeneratingListener listener = new SummaryGeneratingListener();
        launcher.registerTestExecutionListeners(listener);

        // 2. Run the tests
        System.out.println("Running User Tests...");
        launcher.execute(request);

        // 3. Generate HTML Report
        generateHtmlReport(listener);
    }

    private static void generateHtmlReport(SummaryGeneratingListener listener) {
        long total = listener.getSummary().getTestsFoundCount();
        long succeeded = listener.getSummary().getTestsSucceededCount();
        long failed = listener.getSummary().getTestsFailedCount();

        StringBuilder html = new StringBuilder();
        html.append("<html><head><title>IHM Project Test Report</title>");
        html.append("<style>");
        html.append("body { font-family: Arial, sans-serif; margin: 40px; }");
        html.append(".header { background-color: #b31b1b; color: white; padding: 20px; }"); // Matches your style.css header color 
        html.append(".summary { margin-top: 20px; padding: 15px; background: #f4f4f4; border-radius: 5px; }");
        html.append(".pass { color: green; font-weight: bold; }");
        html.append(".fail { color: red; font-weight: bold; }");
        html.append("</style></head><body>");

        html.append("<div class='header'><h1>User Acceptance Test Report</h1>");
        html.append("<p>Generated on: ").append(LocalDateTime.now()).append("</p></div>");

        html.append("<div class='summary'>");
        html.append("<h2>Summary</h2>");
        html.append("<p>Total Tests: ").append(total).append("</p>");
        html.append("<p>Succeeded: <span class='pass'>").append(succeeded).append("</span></p>");
        html.append("<p>Failed: <span class='fail'>").append(failed).append("</span></p>");
        html.append("</div>");

        html.append("<h3>Test Scope</h3>");
        html.append("<p>Testing 'HelloApplication' navigation and 'ArxivApp' search functionality.</p>");
        
        html.append("</body></html>");

        // Write to file
        try (PrintWriter out = new PrintWriter(new FileWriter("TestReport.html"))) {
            out.println(html.toString());
            System.out.println("Report generated: TestReport.html");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
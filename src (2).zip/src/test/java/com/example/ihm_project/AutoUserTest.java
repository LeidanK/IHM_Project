package com.example.ihm_project;

import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.stage.Stage;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.testfx.framework.junit5.ApplicationTest;
import org.testfx.util.WaitForAsyncUtils;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import static org.testfx.api.FxAssert.verifyThat;
import static org.testfx.matcher.base.NodeMatchers.isVisible;
import static org.testfx.matcher.control.LabeledMatchers.hasText;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class AutoUserTest extends ApplicationTest {

    @Override
    public void start(Stage stage) {
        new HelloApplication().start(stage);
        // Force window size to ensure footer is visible above taskbar
        stage.setWidth(1200);
        stage.setHeight(700);
        stage.centerOnScreen();
    }

    // --- HELPER METHODS ---
    private void navigateToArticlesPage() {
        interact(() -> {
            ScrollPane scroll = lookup(".scroll-pane").query();
            if (scroll != null) scroll.setVvalue(1.0);
        });
        
        try { Thread.sleep(500); } catch (InterruptedException e) {}

        clickOn("Passer vers Articles");

        try {
            WaitForAsyncUtils.waitFor(15, TimeUnit.SECONDS, () -> 
                lookup(".cornell-label").tryQuery().isPresent()
            );
        } catch (TimeoutException e) {
            System.out.println("Timeout: ArxivApp did not load in time.");
        }
    }

    // --- TEST CASES ---

    @Test
    @Order(1)
    public void testLandingPageElements() {
        // Verify Title and Intro
        verifyThat(".root", isVisible());
        // Verify Footer Links exist (Checking "About" and "Help")
        interact(() -> {
            ScrollPane scroll = lookup(".scroll-pane").query();
            if (scroll != null) scroll.setVvalue(1.0); // Scroll down to see footer
        });
        verifyThat("About", isVisible());
        verifyThat("Help", isVisible());
    }

    @Test
    @Order(2)
    public void testHomePageSearch() {
        // Test the filter on the main page (filters categories)
        interact(() -> {
            ScrollPane scroll = lookup(".scroll-pane").query();
            if (scroll != null) scroll.setVvalue(0.0); // Scroll top
        });
        
        clickOn(".text-field").write("Computer");
        WaitForAsyncUtils.waitForFxEvents();
        // We verify the application doesn't crash and field contains text
        verifyThat(".text-field", hasText("Computer"));
    }

    @Test
    @Order(3)
    public void testNavigationToArticles() {
        navigateToArticlesPage();
        verifyThat(".cornell-label", isVisible());
        // Check for return button partially to avoid symbol issues
        verifyThat(lookup(".button").match(n -> 
            n instanceof Button && ((Button) n).getText().contains("Retour")
        ), isVisible());
    }

    @Test
    @Order(4)
    public void testArticleSearchFunction() {
        navigateToArticlesPage();

        // Search for a specific topic
        clickOn(".text-field").write("Language");
        WaitForAsyncUtils.waitForFxEvents();
        
        // Verify results container is visible
        verifyThat(".article-scroll", isVisible());
    }

    @Test
    @Order(5)
    public void testReturnNavigation() {
        navigateToArticlesPage();

        // Click Return
        Button returnBtn = lookup(".button").match(n -> 
            n instanceof Button && ((Button) n).getText().contains("Retour")
        ).query();
        clickOn(returnBtn);

        // Verify we are back (Check for a unique element of Home Page, like 'Passer vers Articles')
        interact(() -> {
            ScrollPane scroll = lookup(".scroll-pane").query();
            if (scroll != null) scroll.setVvalue(1.0);
        });
        try { Thread.sleep(500); } catch (InterruptedException e) {}
        
        verifyThat("Passer vers Articles", isVisible());
    }
}